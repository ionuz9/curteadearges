import { Collection } from 'common';
import Block from './Block';

export default class Blocks extends Collection {}

Blocks.prototype.model = Block;
