export { Collection as default } from 'backbone';
