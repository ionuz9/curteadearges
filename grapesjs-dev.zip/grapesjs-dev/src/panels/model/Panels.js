import Backbone from 'backbone';
import Panel from './Panel';

export default Backbone.Collection.extend({
  model: Panel
});
